import React from 'react';
import { At, Telephone } from 'react-bootstrap-icons';

function CompanyInformation() {

  return (
    <>
        <div className="row shadow-sm p-3 mb-2 bg-body rounded border">
            <div className="w-6 px-1">
                <div className="avatar gradient-color mx-0">CN</div> </div>
            <div className="col-md-4 px-0"> <h4 className="col-md-12 px-0 my-0">Company Name</h4>
                <p className="my-0 fs-6">Customer ID: <span>#12345678910</span></p> </div>
            <div className="col-md-5">
                <p className="my-0 d-flex align-items-center fs-6">
                    <At size={28} className="ml-2 mr-1" /><span>Email Address:</span> <span className="mx-1">john@company.com</span></p>
                <p className="my-0 d-flex align-items-center fs-6"><Telephone size={20} className="ml-2 mr-1" /><span className="ms-2">Phone Number:</span> <span className="mx-1">#12345678910</span></p>
            </div>
        </div>
    </>
  );
}

export default CompanyInformation;