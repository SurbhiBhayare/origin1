import React from 'react';
import { useEffect, useState } from 'react';
import axios from 'axios';

function PoDetails() {
    const [data, setData] = useState([]);
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8080/continuum/PO/search');
                setData(response.data);

            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, []);
    // console.log(data)
    // console.log(data[0]);

    return (


        <>
            {data.map((item) => (
                <div key={item.id}>
            {/* <div className="row justify-content-center shadow-sm p-3 mt-2 bg-body rounded border">
                <div className="fw-bold d-flex align-items-center mb-3">
                    <div className="text-white rounded-circle title-icon gradient-color mr-2">
                        <i className="bi bi-card-list" size={14} />
                    </div>
                    <h5 className="fw-bold mb-0">PO Details</h5>
                </div>
                <div className="col-md-3">
                    <h6 className="fw-bold">Po Number</h6>
                    <p className="mb-0">{item.ponumber}</p>
                </div>
                <div className="col-md-3">
                    <h6 className="fw-bold">Buyer ID</h6>
                    <p className="mb-0">{data[0].customer.customerId}</p>
                </div>
                <div className="col-md-3">
                    <h6 className="fw-bold">Buyer Name</h6>
                    <p className="mb-0">{item}</p>
                </div>
                <div className="col-md-3">
                    <h6 className="fw-bold">Email Address</h6>
                    <p className="mb-0">{item.customer.email}</p>
                </div>
            </div> */}
            </div>
            ))}
        </>
   );
}

export default PoDetails;