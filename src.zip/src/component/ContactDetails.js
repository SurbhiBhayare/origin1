import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';
function ContactDetails() {

    // const [data, setData] = useState([]);
    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const response = await axios.get('http://localhost:8080/continuum/PO/search');
    //             setData(response.data);

    //         } catch (error) {
    //             console.error('Error fetching data:', error);
    //         }
    //     };
    //     fetchData();
    // }, []);
    // console.log(data)

    return (
        <>
           
            <div className="row justify-content-center shadow-sm p-3 mt-2 bg-body rounded border">
                <div className="row px-0">
                    <div className="d-block col-md-10">
                        <div className="fw-bold d-flex align-items-center mb-3">
                            <div className="text-white rounded-circle title-icon gradient-color mr-2">
                                <i className="bi bi-card-list" size={14} />
                            </div>
                            <h5 className="fw-bold mb-0">Contact Details</h5>
                        </div>
                    </div>

                    <div className="col-md-2 text-right">
                        <input type="checkbox" /> Same as PO Details
                    </div>
                </div>
                <div className="col-md-4">
                    <label for="exampleInputEmail1" className="form-label fw-bold">Name<span className="text-danger">*</span> </label>
                    <input type="text" className="form-control" placeholder="Enter" required />
                </div>
                <div className="col-md-4">
                    <label for="exampleInputPassword1" className="form-label fw-bold">Email Address <span className="text-danger">*</span></label>
                    <input type="email" className="form-control" placeholder="Enter" required />
                </div>
                <div className="col-md-4">
                    <label for="exampleInputPassword1" className="form-label fw-bold">Phone Number<span className="text-danger">*</span></label>
                    <input type="phone" className="form-control" placeholder="Enter" required />
                </div>
            </div>
            
        </>
    );
}

export default ContactDetails;